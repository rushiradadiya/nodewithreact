// Copyright (c) 2014-present, Facebook, Inc. All rights reserved.

module.exports = {
    presets: ['@babel/preset-env', 'module:metro-react-native-babel-preset'],
};